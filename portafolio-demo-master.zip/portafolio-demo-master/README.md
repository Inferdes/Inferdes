# Portafolio Demo

Es una pagina web creada como modelo para un sitio web personal. Este proyecto fue desarrollado desde 0 utilizando HTML5 y CSS3. Cuenta con una interfaz responsiva programada para una adaptación fluida en cualquier tipo de pantalla

> El desarrollo de este proyectos toma inspiración en los cursos de la carrera de Arquitectura Frontend de Platzi, ademas toma como modelo a uno de sus profesores (Leonidas Esteban).
